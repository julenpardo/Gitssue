""" Insert current directory in path. """

import sys
import os

sys.path.insert(0, os.getcwd())
